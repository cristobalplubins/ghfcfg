# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Clientes(models.Model):
    idclientes = models.AutoField(db_column='idClientes', primary_key=True)  # Field name made lowercase.
    nombre = models.CharField(max_length=45, blank=True, null=True)
    email = models.CharField(max_length=25, blank=True, null=True)
    numero_contacto = models.CharField(max_length=15, blank=True, null=True)
    sexo = models.CharField(max_length=10, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'clientes'


class Listaproductos(models.Model):
    idventas_has_productos = models.AutoField(db_column='idVentas_has_Productos', primary_key=True)  # Field name made lowercase.
    productos_idproductos = models.ForeignKey('Productos', models.DO_NOTHING, db_column='Productos_idProductos')  # Field name made lowercase.
    ventas_idventas = models.ForeignKey('Ventas', models.DO_NOTHING, db_column='Ventas_idVentas')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'listaproductos'
        unique_together = (('idventas_has_productos', 'productos_idproductos', 'ventas_idventas'),)


class Productos(models.Model):
    idproductos = models.AutoField(db_column='idProductos', primary_key=True)  # Field name made lowercase.
    nombre = models.CharField(max_length=20, blank=True, null=True)
    codigo = models.CharField(max_length=10, blank=True, null=True)
    descripcion = models.CharField(max_length=50, blank=True, null=True)
    tamanho_disponible = models.CharField(max_length=45, blank=True, null=True)
    color_disponible = models.CharField(max_length=45, blank=True, null=True)
    precio = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'productos'


class Ventas(models.Model):
    idventas = models.AutoField(db_column='idVentas', primary_key=True)  # Field name made lowercase.
    medio_pago = models.CharField(max_length=10, blank=True, null=True)
    fecha_entrega = models.DateField(blank=True, null=True)
    lugar_entrega = models.CharField(max_length=45, blank=True, null=True)
    monto_venta = models.IntegerField(blank=True, null=True)
    clientes_idclientes = models.ForeignKey(Clientes, models.DO_NOTHING, db_column='Clientes_idClientes')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'ventas'
        unique_together = (('idventas', 'clientes_idclientes'),)
