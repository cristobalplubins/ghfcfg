from django.apps import AppConfig


class MatakiappConfig(AppConfig):
    name = 'Matakiapp'
