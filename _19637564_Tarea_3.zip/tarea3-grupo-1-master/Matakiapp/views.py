from django.shortcuts import render

# Create your views here.
def index(request):
	return render(request,'Matakiapp/index.html')

def producto(request):
	return render(request,'Matakiapp/producto.html')

def galeria(request):
	return render(request,'Matakiapp/galeria.html')

def sube_tu_diseño(request):
	return render(request,'Matakiapp/sube_tu_diseño.html')
    
def contacto(request):
	return render(request,'Matakiapp/contacto.html')

def reservas(request):
	return render(request,'Matakiapp/reservas.html')

def resultado_solicitud(request):
	dato_nombre=request.POST['nombre']
	dato_email=request.POST['correo']
	dato_fono=request.POST['fono']
	sticker_diseñado=request.POST['diseño']
	dato_pago=request.POST['pago']
	dato_lugar=request.POST['lugar_entrega']
	dato_fecha=request.POST['fecha_entrega']
	contexto={"nombre":dato_nombre,"correo":dato_email,"fono":dato_fono,"diseño":sticker_diseñado, "pago":dato_pago, "lugar_entrega":dato_lugar, "fecha_entrega":dato_fecha}
	return render(request, 'Matakiapp/resultado_solicitud.html', contexto)

def resultados(request):
	dato_nombre = request.POST['nombre']
	dato_apellido = request.POST['apellido']
	dato_fono = request.POST['fono']
	dato_email = request.POST['correo']
	dato_sexo = request.POST['sexo']
	dato_consultas = request.POST['consultas']
	contexto = {"nombre": dato_nombre, "apellido":dato_apellido, "fono": dato_fono, "correo": dato_email, "sexo": dato_sexo, "consultas": dato_consultas }
	return render(request, 'Matakiapp/resultados.html', contexto)
   
