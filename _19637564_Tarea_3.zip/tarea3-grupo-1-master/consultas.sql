USE bd_proyecto;

-- -----------------------------------------------------
-- Visualizacion de datos
-- -----------------------------------------------------
SELECT * FROM Clientes;
SELECT * FROM Productos;
Select * FROM Ventas;

-- -----------------------------------------------------
-- CONSULTAS
-- -----------------------------------------------------

INSERT INTO Clientes (nombre, email, numero_contacto, sexo) VALUES ('Matias Alfero',
'mati.alfero@gmail.com', '+56995729983', 'Masculino');
SELECT * FROM Clientes; -- revision

INSERT INTO Productos (nombre,codigo,descripcion,tamanho_disponible,color_disponible,precio) VALUES ('Pinha','P-002','Piña de diversos colores', '15cm x 10cm','Color', '2990');
INSERT INTO Productos (nombre, codigo, descripcion, tamanho_disponible, color_disponible, precio) VALUES ('Lobo',
'L-002', 'Lobo en sombras', '30cm x 20cm','blanco y negro', '4990');
SELECT * FROM Productos; -- revision

INSERT INTO Ventas (medio_pago, fecha_entrega, lugar_entrega, monto_venta, Clientes_idClientes) VALUES ('Efectivo',
'2018-11-26', 'Metro Tobalaba', '2990',1);
SELECT * FROM Ventas; -- revision

UPDATE Clientes SET sexo='Femenino' WHERE idCLientes=1;
SELECT * FROM Clientes; -- revision

UPDATE Productos SET precio='3990' WHERE idProductos=2;
DELETE FROM Productos WHERE idProductos=1;
SELECT * FROM Productos;